# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'b3b63418900864356d1ae109c9186c05b499d427a34b1408e3ea1087761581974db35006cc5d9d7c08e64705720a8a5e683bd895c51c8e953dedd69a74342d08'